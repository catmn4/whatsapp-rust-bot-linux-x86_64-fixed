#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
# The bundled yt-dlp invokes Deno by name to solve YouTube JS challenges.
export PATH="$PWD/libraries:$PATH"
exec ./whatsapp-rust-bot
